/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shapeapplication;

import shape2d.*;
import java.util.*;

/**
 *
 * @author asus
 */
public class ShapeApplication {

    public static void inHinh(Object o) {
        if (o instanceof Hinh) {
            Hinh hinh = (Hinh) o;
            hinh.ve();
        } else {
            System.out.println("Kiểu dữ liệu trên không được hỗ trợ");
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Hinh> danhSachHinh = new ArrayList<>();
        
        danhSachHinh.add(new HinhVuong());
        danhSachHinh.add(new ChuNhat());
        danhSachHinh.add(new TamGiac());
        
        for (Hinh hinh: danhSachHinh) {
            hinh.nhapThongSo();
        }
        
        for (int i = 0; i < danhSachHinh.size(); i++) {
            Hinh hinh = danhSachHinh.get(i);
            System.out.println("Kiểm tra loại hình");
            if (hinh instanceof Object) {
                System.out.println("--- Object ---");
            }
            if (hinh instanceof Hinh) {
                System.out.println("--- Hinh ---");
            }
            
            if (hinh instanceof ChuNhat) {
                System.out.println("---Hình chữ nhật---");
            }
            
            if (hinh instanceof HinhVuong) {
                System.out.println("---Hình vuông---");
                HinhVuong hinhVuong = (HinhVuong) hinh;
                hinhVuong.phuongThucRiengCuaHinhVuong();
            }
            
            if (hinh instanceof TamGiac) {
                System.out.println("---Hình tam giác---");
            }
            
            hinh.inRaThongSo();
            hinh.ve();
        }
        
        
        ArrayList<Object> objects = new ArrayList<>();
        objects.addAll(danhSachHinh);
        objects.add(new String("Một chuỗi"));
        for (Object o: objects) {
            inHinh(o);
        }
    }
    
}
