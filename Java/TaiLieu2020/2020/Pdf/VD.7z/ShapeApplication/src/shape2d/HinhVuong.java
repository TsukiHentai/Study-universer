/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape2d;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class HinhVuong extends ChuNhat {
    @Override
    public void nhapThongSo() {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Nhập kích thước của hình vuông: ");
        for (;;) {
            double a = sc.nextDouble();
            if (a > 0) {
                dai = a;
                rong = a;
                break;
            }
            
            System.out.println("Kích thước hình vuông phải là số dương!");
            System.out.print("Hãy nhập lại kích thước cho hình vuông: ");
        }
    }
    
    public void phuongThucRiengCuaHinhVuong() {
        System.out.println("---------------***---------------");
    }
    
    @Override
    public void inRaThongSo() {
        System.out.println("Hình vông có kích thước: " + dai + " x " + rong);
        System.out.println("Diện tích: " + dienTich());
        System.out.println("Chu vi: " + chuVi());
    }
}
