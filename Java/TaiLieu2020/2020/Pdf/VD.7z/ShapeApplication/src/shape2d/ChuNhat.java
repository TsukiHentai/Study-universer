/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape2d;


import java.util.Scanner;

/**
 *
 * @author asus
 */
public class ChuNhat implements Hinh {
    protected double dai;
    protected double rong;

    @Override
    public double dienTich() {
        return dai * rong;
    }

    @Override
    public double chuVi() {
        return 2 * (dai + rong);
    }

    @Override
    public void ve() {
        int dai = (int) this.dai;
        int rong = (int) this.rong;
        
        for (int i = 0; i < rong; i++) {
            for (int j = 0; j < dai; j++) {
                System.out.print("*");
            }
            System.out.println();
        }
    }
    

    @Override
    public void nhapThongSo() {
        Scanner sc = new Scanner(System.in);
        
        System.out.print("Nhập chiều dài và chiều rộng của hình chữ nhật: ");
        for (;;) {
            dai = sc.nextDouble();
            rong = sc.nextDouble();
            if (dai > 0 && rong > 0) {
                break;
            }
            
            System.out.println("Chiều dài và chiều rộng của hình chữ nhật phải là số dương!");
        }
        // throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    @Override
    public void inRaThongSo() {
        System.out.println("Hình chữ nhật có kích thước: " + dai + " x " + rong);
        System.out.println("Diện tích: " + dienTich());
        System.out.println("Chu vi: " + chuVi());
    }
}
