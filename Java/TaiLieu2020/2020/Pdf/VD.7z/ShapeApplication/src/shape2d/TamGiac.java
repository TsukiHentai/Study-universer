/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package shape2d;


import java.util.Scanner;
/**
 *
 * @author asus
 */
public class TamGiac implements Hinh {
    protected double a, b, c;
    
    @Override
    public double dienTich() {
        double p = chuVi();
        return Math.sqrt(p * (p - a) * (p - b) * (p - c));
    }

    @Override
    public double chuVi() {
        return (a + b + c);
    }

    @Override
    public void ve() {
        System.out.println("-------/\\-------");
        System.out.println("------/**\\------");
        System.out.println("-----/****\\-----");
        System.out.println("----/******\\----");
        System.out.println("----------------");
    }

    @Override
    public void nhapThongSo() {
        Scanner sc = new Scanner(System.in);
        
        for (;;) {
            System.out.print("Nhập độ dài 3 cạnh của tam giác: ");
            a = sc.nextDouble();
            b = sc.nextDouble();
            c = sc.nextDouble();
            
            if (a > 0 && b > 0 && c > 0) {
                if (a - b < c && a + b > c) {
                    break;
                }
            }
            
            System.out.println("Các giá trị vừa nhập vào không phải là chiều dài của 3 cạnh tam giác!");
        }
    }

    @Override
    public void inRaThongSo() {
        System.out.println("Chiều dài 3 cạnh tam giác là: " + a + " " + b + " " + c);
        System.out.println("Chu vi: " + chuVi());
        System.out.println("Diện tích: " + dienTich());
    }
    
}
