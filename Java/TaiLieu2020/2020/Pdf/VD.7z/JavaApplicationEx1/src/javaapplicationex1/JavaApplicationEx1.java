/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplicationex1;

import javaapplicationex1.student.Transcript;

/**
 *
 * @author asus
 */
public class JavaApplicationEx1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Transcript transcript = new Transcript();
        
        transcript.addCourse("ET1234", "Title of ET1234", 3, 3.5f);
        transcript.addCourse("ET8888", "Title of ET8888", 3, 3.0f);
        transcript.addCourse("ET6666", "Title of ET6666", 2, 2.0f);
        
        System.out.println(transcript.toCsv());
        
        transcript.updateCourse("ET1234", "Title of ET1234 (updated)");
        System.out.println(transcript.toCsvOrderByGrade(true));
        
        transcript.updateCourse("ET6666", 4); //
        transcript.updateCourse("ET1234", 4.0f);
        transcript.updateCourse("ET8888", "Title of ET8888 (updated)", 4, 2.5f);
        
        System.out.println(transcript.toCsvOrderByGrade(false));
        
        System.out.println("--- A -> Z ---");
        System.out.println(transcript.toCsvOrderByCourseId(true));
        
        System.out.println("--- Z -> A ---");
        System.out.println(transcript.toCsvOrderByCourseId(false));
    }
    
}
