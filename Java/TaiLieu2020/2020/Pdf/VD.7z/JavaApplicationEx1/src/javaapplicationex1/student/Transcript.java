/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplicationex1.student;

/**
 *
 * @author asus
 */
public class Transcript {
    private final static int MAX_COURSE = 200;
    class Course {
        public String id;
        public String title;
        public int credits;
        public float grade;
        
        public String toCsv() {
            String csv = id + ", "
                    + title + ", "
                    + credits + ", "
                    + grade;
            
            return csv;
        }
    }
    
    private Course[] courseArray = new Course[MAX_COURSE];
    private int nCourse;
    
    public Transcript() {
        nCourse = 0;
    }
    
    private int indexOfCourse(String courseId) {
        for (int i = 0; i < nCourse; i++) {
            if (courseArray[i].id.equals(courseId)) {
                return i;
            }
        }
        
        return -1;
    }
    
    public void addCourse(String courseId, String courseTitle, int credits, float grade) {
        if (indexOfCourse(courseId) == -1) {
            Course course = new Course();
            course.id = courseId;
            course.title = courseTitle;
            course.grade = grade;
            course.credits = credits;
            courseArray[nCourse] = course;
            nCourse++;
        } else {
            updateCourse(courseId, courseTitle, credits, grade);
        }
    }
    
    public void updateCourse(String courseId, String courseTitle, int credits, float grade) {
        int courseIndex = indexOfCourse(courseId);
        if (courseIndex != -1) {
            courseArray[courseIndex].title = courseTitle;
            courseArray[courseIndex].credits = credits;
            courseArray[courseIndex].grade = grade;
        }
    }
    
    public void updateCourse(String courseId, String courseTitle) {
        int courseIndex = indexOfCourse(courseId);
        if (courseIndex != -1) {
            courseArray[courseIndex].title = courseTitle;
        }
    }
    
    public void updateCourse(String courseId, float grade) {
        int courseIndex = indexOfCourse(courseId);
        if (courseIndex != -1) {
            courseArray[courseIndex].grade = grade;
        }
    }
    
    public void updateCourse(String courseId, int credits) {
        int courseIndex = indexOfCourse(courseId);
        if (courseIndex != -1) {
            courseArray[courseIndex].credits = credits;
        }
    }
    
    public float courseGrade(String courseId) {
        int courseIndex = indexOfCourse(courseId);
        if (courseIndex != -1) {
            return courseArray[courseIndex].grade;
        }
        
        return -1.0f;
    }
    
    public int totalCredits() {
        int total = 0;
        for (int i = 0; i < nCourse; i++) {
            total += courseArray[i].credits;
        }
        
        return total;
    }
    
    public float gradePointAverage() {
        float acc = 0;
        int total = 0; // totalCredits();
        for (int i = 0; i < nCourse; i++) {
            acc += courseArray[i].credits * courseArray[i].grade;
            total += courseArray[i].credits;
        }
        
        return acc / total;
    }
    
    public String toCsv() {
        String csv = "";
        for (int i = 0; i < nCourse; i++) {
            String row = courseArray[i].toCsv();
            csv += row + "\r\n";
        }
        
        return csv;
    }
    
    public String toCsvOrderByGrade(boolean order) {
        Course[] courseArrayClone = courseArray.clone();
        
        // Sorting
        for (int i = 0; i < nCourse; i++) {
            for (int j = nCourse - 1; j > i; j--) {
                if (order) {
                    if (courseArrayClone[j].grade < courseArrayClone[j - 1].grade) {
                        Course tmpCourse = courseArrayClone[j];
                        courseArrayClone[j] = courseArrayClone[j - 1];
                        courseArrayClone[j - 1] = tmpCourse;
                    }
                } else {
                    if (courseArrayClone[j].grade > courseArrayClone[j - 1].grade) {
                        Course tmpCourse = courseArrayClone[j];
                        courseArrayClone[j] = courseArrayClone[j - 1];
                        courseArrayClone[j - 1] = tmpCourse;
                    }
                }
                
            }
        }
        
        String csv = "";
        for (int i = 0; i < nCourse; i++) {
            String row = courseArrayClone[i].toCsv();
            csv += row + "\r\n";
        }
        
        return csv;
    }
    
    public String toCsvOrderByCourseId(boolean order) {
        Course[] courseArrayClone = courseArray.clone();
        
        for (int i = 0; i < nCourse; i++) {
            for (int j = nCourse - 1; j > i; j--) {
                if (order) {
                    if (courseArrayClone[j].id.compareTo(courseArrayClone[j - 1].id) < 0) {
                        Course tmpCourse = courseArrayClone[j];
                        courseArrayClone[j] = courseArrayClone[j - 1];
                        courseArrayClone[j - 1] = tmpCourse;
                    }
                } else {
                    if (courseArrayClone[j].id.compareTo(courseArrayClone[j - 1].id) > 0) {
                        Course tmpCourse = courseArrayClone[j];
                        courseArrayClone[j] = courseArrayClone[j - 1];
                        courseArrayClone[j - 1] = tmpCourse;
                    }
                }
                
            }
        }
        
        String csv = "";
        for (int i = 0; i < nCourse; i++) {
            String row = courseArrayClone[i].toCsv();
            csv += row + "\r\n";
        }
        
        return csv;
    }
}

