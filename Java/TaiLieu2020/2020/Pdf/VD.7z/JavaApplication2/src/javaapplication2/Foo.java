/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

/**
 *
 * @author asus
 */
class Foo extends Bar{
    String name;
    
    Foo() {
        name = "Unknown";
    }
    
    Foo(String name) {
        this.name = name;
    }
    
    @Override
    public void print(String str) {
        System.out.println("Hello world!");
    }
    
    @Override
    public void shout() {
        System.out.println("Hello world!");
    }
}

abstract class Bar {
    public void print(String str) {
        System.out.println("Hello world!");
    }
    public abstract void shout();
}
