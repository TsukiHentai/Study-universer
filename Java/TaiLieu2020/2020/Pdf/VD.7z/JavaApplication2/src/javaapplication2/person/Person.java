/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2.person;

/**
 *
 * @author asus
 */
public class Person {
    private String name;
    public String dateOfBirth;
    public int count = 0;
    
    public Person() {
        name = "Vô danh";
        count++;
    }
    
    public Person(String _name) {
        name = _name;
        count++;
    }
    
    public Person(String _name, String _dateOfBirth) {
        name = _name;
        dateOfBirth = _dateOfBirth;
        count++;
    }
    
    public String getName() {
        return name;
    }
    
    // Method Overloading
    public void setName(String name) {
        this.name = name;
    }
    
    // Method Overloading
    public void setName(String firstName, String lastName) {
        this.name = firstName + " " + lastName;
    }
}
