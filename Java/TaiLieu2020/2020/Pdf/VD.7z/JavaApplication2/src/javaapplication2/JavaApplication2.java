/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplication2;

import java.util.Scanner;
import javaapplication2.person.*;

/**
 *
 * @author asus
 */
public class JavaApplication2 {
    // Khai bao hằng
    private static final float PI = 3.14f;
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int[][] array2D;
        array2D = new int[5][3];
        
        for (int i = 0; i < array2D.length; i++) {
            // System.out.println(i);
            for (int j = 0; j < array2D[i].length; j++) {
                array2D[i][j] = Integer.valueOf(String.valueOf(i) + String.valueOf(j));
            }
        }
        
        for (int[] array1D: array2D) {
            for (int element: array1D) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
    
}
