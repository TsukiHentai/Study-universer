/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplicationfile;

import java.util.*;
import java.io.*;

/**
 *
 * @author asus
 */
public class JavaApplicationFile {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        try {
            FileWriter file = new FileWriter("data.txt");
            PrintWriter outStream = new PrintWriter(file);
            
            outStream.println("Một dòng!");
            outStream.println(3.14d);
            outStream.print("PI = ");
            double pi = 3.1413f;
            outStream.print(pi);
            outStream.println();
            outStream.format("PI = %f", pi);
            outStream.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        
        // Đọc dữ liệu
        try {
            FileReader file = new FileReader("data.txt");
            BufferedReader bufferIn = new BufferedReader(file);
            String firstLine = bufferIn.readLine();
            System.out.println("Dòng đầu tiên đọc được:");
            System.out.println(firstLine);
            Scanner sc = new Scanner(bufferIn);
            if (sc.hasNextDouble()) {
                double pi = sc.nextDouble();
                System.out.format("Giá trị đọc được là PI = %f", pi);
            }
            bufferIn.close();
        } catch (IOException ex) {
            System.out.print(ex.getMessage());
        }
    }
    
}
