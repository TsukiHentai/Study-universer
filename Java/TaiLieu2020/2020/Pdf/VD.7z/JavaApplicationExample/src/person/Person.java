/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package person;

/**
 *
 * @author asus
 */
public class Person {
    public String name;
    public String gender;
    
    public static int count = 0;

    public Person() {
        count++;
    }

    public Person(String _name) {
        name = _name;
        count++;
    }

    public Person(String _name, String _gender) {
        name = _name;
        gender = _gender;
        count++;
    }
}
