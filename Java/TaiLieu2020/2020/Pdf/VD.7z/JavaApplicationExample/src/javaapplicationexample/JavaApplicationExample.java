/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplicationexample;


import java.util.Scanner;

/**
 *
 * @author asus
 */
public class JavaApplicationExample {
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String str = "";
        int n;
        float z;
        
        // Khai báo Scanner mới lấy dữ liệu từ bàn phím (System.in)
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhập một chuỗi bất kỳ: ");
        str = sc.nextLine();
        
        System.out.print("Chuỗi vừa nhập là: ");
        System.out.println(str);
        
        //
        System.out.print("Nhập một số nguyên: ");
        n = sc.nextInt();
        
        System.out.print("Số nguyên vừa nhập là: ");
        System.out.println(n);
        
        //
        System.out.print("Nhập một số thực: ");
        z = sc.nextFloat();
        
        System.out.print("Số thực vừa nhập là: ");
        System.out.println(z);
    }
    
}
