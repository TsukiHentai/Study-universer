/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex1;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class Ex1 {

    private static boolean kiemTraNamNhuan(int nam) {
        return ((nam % 4 == 0) && (nam % 100 != 0)) ||
                (nam % 400 == 0);
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int nam1, nam2;
        
        Scanner sc = new Scanner(System.in);
        nam1 = sc.nextInt();
        nam2 = sc.nextInt();
        
        int n1, n2;
        int tong = 0;
        if (nam1 > nam2) {
            n1 = nam2;
            n2 = nam1;
        } else {
            n1 = nam1;
            n2 = nam2;
        }
        
        for (; n1 <= n2; n1++) {
            tong += kiemTraNamNhuan(n1) ? 366: 365;
        }
        
    }
    
}
