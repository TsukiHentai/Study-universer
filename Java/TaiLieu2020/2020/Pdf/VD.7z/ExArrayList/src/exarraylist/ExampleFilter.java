/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exarraylist;

import java.util.*;
import java.util.function.Predicate;

/**
 *
 * @author asus
 */
public class ExampleFilter implements Predicate<Integer> {
    public boolean test(Integer i1) {
        if (i1 > 100) {
            return true;
        } else {
            return false;
        }
    }
}
