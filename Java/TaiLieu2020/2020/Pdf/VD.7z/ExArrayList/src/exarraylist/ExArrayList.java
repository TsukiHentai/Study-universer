/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exarraylist;

import java.util.*;

/**
 *
 * @author asus
 */
public class ExArrayList {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String comment = "For comment";
        ArrayList<Integer> array;
        array = new ArrayList<Integer>();
        // Generic types -> Template (C++)
        Scanner sc = new Scanner(System.in);
        while (true) {
            int n = sc.nextInt();
            if (n > 0) {
                array.add(n);
            } else {
                break;
            }
        }
        
        for (int i = 0; i < array.size(); i++) {
            System.out.println("array[" + i + "] = " + array.get(i));
        }
        
        System.out.println("Nhập phần tử muốn chèn thêm vào: ");
        int index = sc.nextInt();
        int val = sc.nextInt();
        array.add(index, val);
        
        for (Integer elem: array) {
            System.out.println("elem: " + elem);
        }
        
        System.out.println("Nhập giá trị muốn tìm kiếm: ");
        int crit = sc.nextInt();
        int result = array.indexOf(crit);
        System.out.println("Tìm thấy giá trị ở vị trí: " + result);
        
        IntegerCompare intCom = new IntegerCompare();
        ArrayList<Integer> arraySort = (ArrayList<Integer>)array.clone();
        // ArrayList<Integer> arraySort = array;

        arraySort.sort(intCom);
        
        for (int i = 0; i < array.size(); i++) {
            System.out.println("array[" + i + "] = " + array.get(i));
        }
        
        System.out.println("Mảng sau khi sắp xếp: ");
        for (int i = 0; i < arraySort.size(); i++) {
            System.out.println("array[" + i + "] = " + arraySort.get(i));
        }
        
        System.out.println("Nhập vị trí phần tử muốn xóa: ");
        int delIndex = sc.nextInt();
        array.remove(delIndex);
        
        
        for (int i = 0; i < array.size(); i++) {
            System.out.println("array[" + i + "] = " + array.get(i));
        }
        
        
        System.out.println("Mảng sau khi loại bỏ các phần tử thỏa mãn filter:");
        // ExampleFilter filter = new ExampleFilter();
        // array.removeIf(filter);
        comment = "Java 8 (1.8)";
        //
        array.removeIf(element -> {
           if (element > 100) {
               return true;
           } else {
               return false;
           }
        });
        
        for (int i = 0; i < array.size(); i++) {
            System.out.println("array[" + i + "] = " + array.get(i));
        }
    }
    
}
