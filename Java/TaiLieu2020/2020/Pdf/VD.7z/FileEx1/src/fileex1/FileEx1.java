/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package fileex1;

import java.io.*;
import java.util.Scanner;
import java.util.regex.*;

/**
 *
 * @author asus
 */
public class FileEx1 {
    public static void tachThoiGian(String str) {
        // 0 - 23
        // 0 - 9 -> \d
        // 00 - 19 - > [01][0-9] -> [01]\d
        // 20 - 23 -> 2[0-3]
        String patt = "(([0-9])|([01][0-9])|(2[0-3]))[:](([0-9])|([0-5][0-9]))";
        Pattern datePattern = Pattern.compile(patt);
            
        Matcher m = datePattern.matcher(str);
        
        while (m.find()) {
            System.out.println("Chuỗi tìm được: " + m.group(0));
            int h = Integer.valueOf(m.group(1));
            int min = Integer.valueOf(m.group(5));
            
            if (h >= 0 && h < 24 
                    && min >= 0 && min < 60) {
                System.out.println("Giờ: " + h);
                System.out.println("Phút: " + min);
            } else {
                System.out.println("Chuỗi " + m.group(0) + " không phải là thời gian hợp lệ");
            }
        }
    }
    
    public static void tachNgayThang(String str) {
        String patt = "\\s+(\\d{1,2})\\/(\\d{1,2})\\/(\\d{4})";
        Pattern datePattern = Pattern.compile(patt);
            
        Matcher m = datePattern.matcher(str);
        while (m.find()) {
            System.out.println("Phần chuỗi ký tự đúng với mẫu kiểm tra:");
            System.out.println(m.group());
            boolean hopLe = true;
            int ngay = Integer.valueOf(m.group(1));
            int thang = Integer.valueOf(m.group(2));
            int nam = Integer.valueOf(m.group(3));

            if (thang > 0 && thang < 13 && ngay > 0) {
                if ((thang < 8) && (thang % 2 == 1)) {
                    if (ngay > 31) {
                        hopLe = false;
                    }
                } else if ((thang < 8) && (thang != 2)) {
                    if (ngay > 30) {
                        hopLe = false;
                    }
                } else if (thang == 2) {
                    // Kiem nam nhuan
                    if (((nam % 4 == 0) && (nam % 100 != 0)) || (nam % 400 == 0)) {
                        if (ngay > 29) {
                            hopLe = false;
                        }
                    } else {
                        if (ngay > 28) {
                            hopLe = false;
                        }
                    }
                } else if (thang % 2 == 0) {
                    if (ngay > 31) {
                        hopLe = false;
                    }
                } else {
                    if (ngay > 30) {
                        hopLe = false;
                    }
                }
            } else {
                hopLe = false;
            }

            if (hopLe) {
                System.out.println("Ngày: " + ngay);
                System.out.println("Tháng: " + thang);
                System.out.println("Năm: " + nam);
            } else {
                System.out.println("Chuỗi vừa tìm được không phải là ngày tháng hợp lệ");
            }
        }
    }
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {        
        // TODO code application logic here
        /*
        try {
            FileWriter out = new FileWriter("data.txt");
            
            Scanner sc = new Scanner(System.in);
            
            System.out.println("Nhập vào một chuỗi ký tự: ");
            String str = sc.nextLine();
            
            out.write("Ví dụ về xử lý file trong java\r\n");
            out.write(str);
            
            out.close();
        } catch (IOException ex) {
            System.out.println(ex.getMessage());
        }
        */
        
        try {
            FileReader in = new FileReader("data.txt");
            // FileOutputStream fileOutputStream = new FileOutputStream("data.txt");
            
            
            System.out.println("Dữ liệu đọc từ file: ");
            char[] buff = new char[255];
            
            while (in.read(buff) != -1) {
                String str = new String(buff);
                System.out.println("Chuỗi ký tự đọc được: ");
                System.out.println(str);
                tachNgayThang(str);
                tachThoiGian(str);
            }
            
            
            
            System.out.println("Đã đọc hết file");
            
            in.close();
        } catch (IOException ex) {
            System.out.println("Có lỗi xảy ra khi đọc file.");
            System.out.println(ex.getMessage());
        }
    }
    
}
