/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

/**
 *
 * @author asus
 */
// Final + class -> Không thể là lớp cha (superClass) của lớp khác
// Không có lớp con
public class Dog extends Animal implements IShout {
    public Dog() {
        
    }
    
    @Override
    public void shout() {
        System.out.println("Gau......");
    }
    
    public int getWeight() {
        return 10;
    }
}
