/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

/**
 *
 * @author asus
 */

public class DogF2 extends Dog {
    public DogF2() {
        
    }
    
    @Override
    public void shout() {
        System.out.println("awwwwww!!!!!");
    }
}
