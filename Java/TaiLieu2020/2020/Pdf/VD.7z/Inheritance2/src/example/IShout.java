/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

/**
 *
 * @author asus
 */
public interface IShout {
    void shout();
    
    // Phương thức mặc định
    // Chỉ ở trong giao diện
    default void printName() {
        System.out.println("Default Implements of printName!");
    }
    
    static void staticShout() {
        System.out.println("An static method!");
    }
}
