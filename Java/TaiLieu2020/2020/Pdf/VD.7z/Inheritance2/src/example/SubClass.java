/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

/**
 *
 * @author asus
 */
// Nếu không kế thừa hết các phương thức trừu tượng thì lớp
// Con phải là lớp trừu tượng
public abstract class SubClass extends SuperClass implements IExample {
    private int subVal;
    public SubClass() {
        super(1);
        subVal = 1111;
    }
    
    public SubClass(int var) {
        super(var); // Phải gọi hàm tạo của lớp cha ở dòng đầu tiên.
        subVal = 12345;
    }
    
    public void subClassMethod() {
        System.out.println("subClassMethod!!!");
    }
    
    // Phải override tất cả các phương thức trừu tượng
    @Override
    public void shout() {
        System.out.println("SubClass");
    }
    
    @Override
    public void exam() {
        System.out.println("SubClass implement of exam!!!");
    }
}
