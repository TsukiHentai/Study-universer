/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package example;

/**
 *
 * @author asus
 */
// Lớp có ít nhất 1 phương thức trừu tượng là lớp trừu tượng.
public abstract class SuperClass {
    protected int var;
    private int priVal;
    
    public SuperClass() {
        System.out.println("Create a SuperClass!");
        var = 0;
        priVal = 0;
    }
    
    public SuperClass(int var) {
        System.out.println("Create SuperClass with params!");
        this.var = var;
    }
    
    public int getVar() {
        return var;
    }
    
    // Phương thức trừu tượng
    public abstract void shout();
}
