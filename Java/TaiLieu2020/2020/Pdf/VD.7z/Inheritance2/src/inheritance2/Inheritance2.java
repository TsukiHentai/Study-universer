/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance2;

import example.*;

/**
 *
 * @author asus
 */
public class Inheritance2 {

    private static void animalShout(IShout iShout) {
        iShout.shout();
        iShout.printName();
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // SubClass sub = new SubClass();
        // Lớp trừu tượng không khai báo được đối tượng
        // Không sử dụng được với toán tử new
        // Giao diện cũng không thể dùng để khai báo đối tượng
        SubClass sub;
        SuperClass sup;
        IExample iExam;
        // Tuy nhiên vẫn có thể sử dụng để khai báo biến.
        TinyClass tiny = new TinyClass();
        
        // Đa hình
        sub = (SubClass) tiny;
        sup = (SuperClass) tiny;
        iExam = (IExample) tiny;
        
        System.out.println("tiny -> sup.shout()");
        sup.shout();
        
        System.out.println("tiny -> iExam.getPi()");
        System.out.println(iExam.getPi());
        
        
        // System.out.println("sub.getVar()");
        // System.out.println(sub.getVar());
        
        // SubClass subVar = new SubClass(123);
        // System.out.println("subVar.getVar()");
        // System.out.println(subVar.getVar());
        
        // subVar.subClassMethod();
        // System.out.println("subVar.shout()");
        // subVar.shout();
        
        // System.out.println("subVar.exam()");
        // subVar.exam();
        
        Dog dog1 = new Dog();
        Cat cat1 = new Cat();
        
        // IShout.staticShout();
        /*
        IShout shout;
        
        
        shout = (IShout) dog1;
        System.out.println("dog1 -> shout.shout()");
        shout.shout();
        
        shout = (IShout) cat1;
        System.out.println("cat -> shout.shout()");
        shout.shout();
        */
        
        System.out.println("animalShout(dog1)");
        animalShout(dog1);
        
        System.out.println("animalShout(cat1)");
        animalShout(cat1);
        
        
        System.out.println("------------ final modifier -------------");
        System.out.println( "dog1 " + dog1.rootClass());
        System.out.println( "cat1 " + cat1.rootClass());
        
        DogF2 dog2 = new DogF2();
        dog2.shout();
    }
    
}
