/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package logger;

/**
 *
 * @author asus
 */
public abstract class Logger {
    protected int threshold;
    
    
    public static class LoggerLevel {
        public static final int EMER = 0; // Emergency
        public static final int ALERT = 1; // Alert
        public static final int CRIT = 2; // Critical
        public static final int ERR = 3; // Err
        public static final int WARNING = 4; // Warning
        public static final int NOTICE = 5; // Notice
        public static final int INFO = 6; // Informational
        public static final int DEBUG = 7; // Debug
        
        public static final String[] NAME_MAPPING = {
            "emer", // 0
            "alert", // 1
            "crit", // 2
            "err", // 3
            "warning", // 4
            "notice", // 5
            "info", // 6
            "debug" // 7
        };
    }
    
    /**
     * Default logger level is error
     */
    public Logger() {
        this(LoggerLevel.ERR);
    }
    
    public Logger(int threshold) {
        this.threshold = threshold;
    }
    
    public void debug(String message){
        loggerFilter(LoggerLevel.DEBUG, message);
    }
    
    public void info(String message) {
        loggerFilter(LoggerLevel.INFO, message);
    }
    
    public void warn(String message) {
        loggerFilter(LoggerLevel.WARNING, message);
    }
    
    public void error(String message) {
        loggerFilter(LoggerLevel.ERR, message);
    }
    
    public void critical(String message) {
        loggerFilter(LoggerLevel.CRIT, message);
    }
    
    public void alert(String message) {
        loggerFilter(LoggerLevel.ALERT, message);
    }
    
    public void emergency(String message) {
        loggerFilter(LoggerLevel.EMER, message);
    }
    
    /**
     * Filter out event logs above threshold 
     * @param logLevel message level
     * @param message logger message
     */
    protected void loggerFilter(int logLevel, String message) {
        if (logLevel <= threshold) {
            loggerFormat(logLevel, message);
        }
    }
    
    /**
     * This method default output format.
     * @param logLevel
     * @param message 
     */
    public abstract void loggerFormat(int logLevel, String message);
}
