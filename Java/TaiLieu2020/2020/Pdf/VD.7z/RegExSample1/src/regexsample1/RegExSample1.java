/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regexsample1;

import java.util.regex.*;
import java.util.Scanner;

/**
 *
 * @author asus
 */
public class RegExSample1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String ngay = "Hôm nay là: 26/10/2017   17:28";
        String msv = "090 999 99 99";
        // pattern -> \d+\/d+\/\d+
        String datePattern = "(\\d+)\\/(\\d+)\\/(\\d+)\\s+(([01][0-9])|(2[0-3]))[:](\\d+)";
        // Group                 1        2        3      45           6              7
        //                                                4: (([01][0-9])|(2[0-3]))
        //                                                5: ([01][0-9])
        Pattern datePat = Pattern.compile(datePattern);
        Scanner sc = new Scanner(System.in);
        System.out.print("Nhap mot chuoi co ngay thang: ");
        String str = sc.nextLine();
        
        System.out.println("Pattern: " + datePattern);
        Matcher m = datePat.matcher(str);
        if (m.find()) {
            System.out.println("Output: " + m.group());
            System.out.println("Ngay: " + m.group(1));
            System.out.println("Thang: " + m.group(2));
            System.out.println("Nam: " + m.group(3));
            System.out.println("Gio: " + m.group(4));
            System.out.println("Phut: " + m.group(7));
        } else {
            System.out.println("Khong tim thay");
        }
    }
    
}
