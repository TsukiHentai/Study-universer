/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package regex2;

import java.util.regex.*;
import java.util.Scanner;

/**
 *
 * @author asus
 */
public class RegEx2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        String ngayThang = "";
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Nhap vao mot ngay: ");
        ngayThang = sc.nextLine();
        
        // VD: 1/11/2017   11:40:58
        // Pattern -> (\d+)\/(\d+)\/(\d+)
        // Group ->
        String pattern = "(\\d+)\\/(\\d+)\\/(\\d+)[ ]+((?:[0-9])|(?:0[0-9])|(?:1[0-9])|(?:2[0-3])):(\\d+):(\\d+)";
        System.out.println("pattern: " + pattern);
        
        Pattern regEx = Pattern.compile(pattern);
        Matcher m = regEx.matcher(ngayThang);
        if (m.find()) {
            System.out.println("Kết quả: ");
            System.out.println(m.group());
            System.out.println("Ngày: " + m.group(1));
            System.out.println("Tháng: " + m.group(2));
            System.out.println("Năm: " + m.group(3));
            System.out.println("Giờ: " + m.group(4));
            System.out.println("Phút: " + m.group(5));
            System.out.println("Giây: " + m.group(6));
        } else {
            System.out.println("Mẫu nhập vào không đúng chuẩn!!!");
        }
    }
    
}
