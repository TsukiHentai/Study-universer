/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionexample2;

import java.util.Scanner;

/**
 *
 * @author asus
 */
public class ExceptionExample2 {

    public static double div(int a, int b) throws DivZeroException, DivZeroZeroException {
        if (b == 0) {
            if (a == 0) {
                DivZeroZeroException divZeroZeroEx = new DivZeroZeroException();
                throw divZeroZeroEx;
            } else {
                throw new DivZeroException();
            }
        } else {
            return a / b;
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Scanner sc = new Scanner(System.in);
        
        int a, b;
        double ab;
        System.out.println("Nhập vào 2 số nguyên: ");
        System.out.print("a = ");
        a = sc.nextInt();
        System.out.print("b = ");
        b = sc.nextInt();
        
        for (int i = a; i <= b; i++) {
            int x, y;
            x = i;
            y = b - (x - a);
            
            double xy;
            
            try {
                xy = div(x, y);
            } catch (DivZeroException ex) {
                // System.out.println("Có lỗi xảy ra khi thực hiện phép chia a / b");
                System.out.println("Phép chia cho 0");
                System.out.println(ex.getMessage());
                // System.out.println(ex.toString());
                continue;
            } catch (DivZeroZeroException ex) {
                System.out.println("Phép chia 0 cho 0!!!");
                System.out.println(ex.toString());
                break;
            } finally {
                System.out.println("------ finally ------");
                System.out.println("x = " + x);
                System.out.println("y = " + y);
                System.out.println("------ finally ------");
            }
            System.out.println(x + " / " + y + " = " + xy);
            System.out.println("Thực hiện vòng lặp tiếp theo");
        }
        
        System.out.println("Chương trình hoàn thành mà không xảy ra lỗi.");
    }
    
}

class DivZeroException extends Exception {
    @Override
    public String getMessage() {
        return "Phép chia cho 0";
    }
}

class DivZeroZeroException extends Exception {
    @Override
    public String getMessage() {
        return "Phép chia 0/0";
    }
}