/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asus
 */
public class Student extends Person implements CsvExport{
    public String studentID;
    
    public Student() {
        name = "Student";
        dateOfBirth = "Cannot access";
    }
    
    public void enroll() {
        //
    }
    
    public void getTranscript() {
        //
    }
    
    @Override
    public String toCsv() {
        return "CSV";
    }
    
    // Overloadding
    public String toCsv(String fileName) {
        return "Overloadding";
    }
}
