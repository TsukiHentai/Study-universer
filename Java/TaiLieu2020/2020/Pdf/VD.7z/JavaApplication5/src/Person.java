/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author asus
 */
public class Person {
    protected String name;
    protected String dateOfBirth;
    
    public Person() {
        name = "";
        dateOfBirth = "dateOfBirth";
    }
    
    public int age() {
        return 10;
    }
}
