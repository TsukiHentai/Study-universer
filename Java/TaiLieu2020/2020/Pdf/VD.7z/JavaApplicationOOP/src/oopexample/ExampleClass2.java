/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopexample;

/**
 *
 * @author asus
 */
public class ExampleClass2 {
    public ExampleClass1 ex1;
    
    public ExampleClass2() {
        ex1 = new ExampleClass1();
    }
    
    public void print() {
        ex1.print();
    }
}
