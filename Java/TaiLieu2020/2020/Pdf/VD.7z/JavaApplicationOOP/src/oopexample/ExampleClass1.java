/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopexample;

/**
 *
 * @author asus
 */
public class ExampleClass1 {
    protected int n;
    
    public ExampleClass1() {
        n = 10;
    }
    
    public void print() {
        System.out.println("Example Class n: " + n);
    }
}
