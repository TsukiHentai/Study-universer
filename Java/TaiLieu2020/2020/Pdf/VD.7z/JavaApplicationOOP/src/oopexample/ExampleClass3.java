/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package oopexample;

/**
 *
 * @author asus
 */
public class ExampleClass3 {
    ExampleClass2 ex2;
    public ExampleClass2 ex222;
    
    public ExampleClass3() {
        ex2 = new ExampleClass2();
    }
    
    public void print() {
        ex2.print();
    }
}
