/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package javaapplicationoop;

import oopexample.*;

/**
 *
 * @author asus
 */
public class JavaApplicationOOP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ExampleClass3 ex3 = new ExampleClass3();
        
        ex3.print();
        ex3.ex222 = new ExampleClass2();
        ex3.ex222.ex1 = new ExampleClass1();
        
    }
    
}
