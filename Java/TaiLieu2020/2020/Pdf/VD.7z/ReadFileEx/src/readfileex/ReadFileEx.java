/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package readfileex;

import java.io.*;
import java.util.Scanner;
import java.util.regex.*;

/**
 *
 * @author asus
 */
public class ReadFileEx {
    public static void kiemTraEmail(String text) {
        
    }
    public static void timKiemNgay(String text) {
        int[] ngayThang = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31};
        //////////////////  1   2  3   4   5   6   7   8   9   10  11  12
        String patStr = "\\s+(\\d+)[-](\\d+)[-](\\d+)\\s+";
        ///////////////////     1        2       3
        ///////////////////     09  -    11  -   2017
        Pattern datePattern = Pattern.compile(patStr);
        Matcher m = datePattern.matcher(text);
        while (m.find()) {
            System.out.println("Chuỗi được tìm thấy: ");
            System.out.println(m.group());
            int ngay = Integer.valueOf(m.group(1));
            int thang = Integer.valueOf(m.group(2));
            int nam = Integer.valueOf(m.group(3));
            if (thang > 0 && thang < 13
                && ngay > 0 && ngay <= ngayThang[thang - 1]) {
                    System.out.println("Ngày tháng vừa tìm thấy là hợp lệ");
            } else {
                System.out.println("Ngày tháng vừa tìm thấy không hợp lệ");
            }
            System.out.println("Ngày: " + ngay);
            System.out.println("Tháng: " + thang);
            System.out.println("Năm: " + nam);
            
        }
        
    }
    
    public static void timKiemThoiGian(String text) {
        //////////////////   1                        2 
        String patStr = "\\s+((?:[01]?[0-9])|(?:2[0-3]))[:]((?:[0-9])|(?:[0-5][0-9]))\\s+";
        //
        // 
        ///Gio:   0-23
        //        0-9 hoặc 00 - 19 hoặc 20 - 23
        //        ([0-9])|([01][0-9])|(2[0-3])
        //        ([01]?[0-9])|(2[0-3])
        // Phut: 0 -59
        // ([0-9])|([0-5][0-9])
        ///////////////////     1        2       3
        ///////////////////     09  -    11  -   2017
        Pattern timePattern = Pattern.compile(patStr);
        Matcher m = timePattern.matcher(text);
        while (m.find()) {
            System.out.println("Chuỗi được tìm thấy: ");
            System.out.println(m.group());
            int gio = Integer.valueOf(m.group(1));
            int phut = Integer.valueOf(m.group(2));
            System.out.println("Giờ: " + gio);
            System.out.println("Phút: " + phut);
            
        }
        
    }
    
    public static void readFile(String filename) {
        try {
            FileInputStream in = new FileInputStream(filename);
            Scanner sc = new Scanner(in);
            String text = sc.nextLine();
            System.out.println("Dòng đầu tiên đọc được ở file là: ");
            System.out.println(text);
            in.close();
        } catch (IOException ex) {
            System.out.println("Có lỗi xảy ra trong quá trình xử lý file!");
            System.out.println(ex.getMessage());
        }
    }
    
    public static void WriteFile(String filename) {
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Nhập một chuỗi ký tự:");
        String text = sc.nextLine();
        
        try {
            FileOutputStream out = new FileOutputStream(filename);
            out.write(text.getBytes());
            out.close();
        } catch (IOException ex) {
            System.out.println("Có lỗi xảy ra trong quá trình xử lý file!");
            System.out.println(ex.getMessage());
        } finally {
        }
    }
    
    public static void fileReaderWrapper(String filename) {
        try {
            FileReader in = new FileReader(filename);
            char[] buff = new char[255];
            while (in.read(buff) != -1) {
                String text = new String(buff);
                System.out.println("Chuỗi ký tự vừa đọc được: ");
                System.out.println(text);
                timKiemNgay(text);
                timKiemThoiGian(text);
            }
            in.close();
        } catch (IOException ex) {
            System.out.println("Có lỗi !!!");
            System.out.println(ex.getMessage());
        }
    }
    
    public static void fileWriterWrapper(String filename) {
        try {
            FileWriter out = new FileWriter(filename);
            Scanner sc = new Scanner(System.in);
            System.out.println("Nhập vào một chuỗi ký tự: ");
            String text = sc.nextLine();
            out.write(text);
            out.close();
        } catch (IOException ex) {
            System.out.println("Có lỗi xảy ra!!!");
            System.out.println(ex.getMessage());
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        // fileWriterWrapper("../data2.txt");
        fileReaderWrapper("../data2.txt");
        // timKiemNgay("Một chuỗi có chứa ngày tháng 09-11-2017 ở giữa");
    }
    
}
