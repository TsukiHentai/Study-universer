/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.*;

/**
 *
 * @author asus
 */
public class FillWord extends Question {
    protected String question;
    protected String answer;
    protected String choice;
    
    @Override
    public void prepare() {
        System.out.println("Nhập nội dung câu hỏi:");
        Scanner sc = new Scanner(System.in);
        question = sc.nextLine();
        System.out.println("Nhập đáp án đúng: ");
        answer = sc.nextLine().trim();
    }

    @Override
    public void print() {
        System.out.println(question);
    }

    @Override
    public void exec() {
        Scanner sc = new Scanner(System.in);
        System.out.println("Nhập kết quả còn thiếu: ");
        choice = sc.nextLine().trim();
    }

    @Override
    public int getScore() {
        return answer.equals(choice) ? 1: 0;
    }
    
}
