/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package test;

import java.util.*;
import java.util.regex.*;

/**
 *
 * @author asus
 */
public class MultipleChoice extends Question {
    protected String question;
    protected ArrayList<MultipleChoiceAnswer> answers;
    protected String choice;
    
    private class MultipleChoiceAnswer {
        public String answer;
        public boolean isTrue;
        
        public MultipleChoiceAnswer(String answer, boolean isTrue) {
            this.answer = answer;
            this.isTrue = isTrue;
        }
    }
    
    public MultipleChoice() {
        answers = new ArrayList<>();
    }
    
    @Override
    public void prepare() {
        System.out.println("Nhập nội dung câu hỏi:");
        Scanner sc = new Scanner(System.in);
        question = sc.nextLine();
        
        for (int i = 1; ; i++) {
            System.out.println("Nhập nội dung đáp án " + i);
            String ans = sc.nextLine();
            System.out.println("Đáp án trên có đúng hay không (Y/N):");
            String isTrueOrFalse = sc.nextLine().trim();
            boolean isTrue = false;
            if (isTrueOrFalse.toLowerCase().equals("y")) {
                isTrue = true;
            }
            
            MultipleChoiceAnswer multipleAns = new MultipleChoiceAnswer(ans, isTrue);
            answers.add(multipleAns);
            System.out.println("Bạn có muốn thêm đáp án khác không (Y/N): ");
            String addAnswer = sc.nextLine().trim().toLowerCase();
            if (!addAnswer.equals("y")) {
                break;
            }
        }
    }

    @Override
    public void print() {
        System.out.println(question);
        for(int i = 0; i < answers.size(); i++) {
            System.out.println( (i + 1) + ". " + answers.get(i).answer);
        }
    }

    @Override
    public void exec() {
        System.out.println("Nhập vào danh sách các đáp án đúng: ");
        Scanner sc = new Scanner(System.in);
        choice = sc.nextLine().trim();
    }

    @Override
    public int getScore() {
        Pattern ansPattern = Pattern.compile("\\d+");
        Matcher choiceMatcher = ansPattern.matcher(choice);
        
        int point = 0;
        
        while (choiceMatcher.find()) {
            int ans = Integer.valueOf(choiceMatcher.group()) - 1;
            if (ans >= answers.size()) {
                continue;
            }
            if (answers.get(ans).isTrue) {
                point++;
            }
        }
        
        return point;
    }
    
}
