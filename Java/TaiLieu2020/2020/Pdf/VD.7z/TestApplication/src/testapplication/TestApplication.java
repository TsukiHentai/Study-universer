/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package testapplication;

import test.*;
import java.util.*;

/**
 *
 * @author asus
 */
public class TestApplication {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Question> questions = new ArrayList<>();
        Scanner sc = new Scanner(System.in);
        for (;;) {
            System.out.println("Chọn loại câu hỏi muốn thêm vào: ");
            System.out.println("1. MultipleChoice");
            System.out.println("2. FillWord");
            System.out.println("3. Không thêm câu hỏi mới");
            String type = sc.nextLine().trim();
            
            Question q;
            if (type.equals("1")) {
                q = new MultipleChoice();
            } else if (type.equals("2")) {
                q = new FillWord();
            } else if (type.equals("3")) {
                break;
            } else {
                System.out.println("Loại câu hỏi trên không được hỗ trợ");
                continue;
            }
            
            q.prepare();
            questions.add(q);
        }
        
        System.out.println("Kiểm tra: ");
        for (Question q: questions) {
            System.out.println("-------------------------------");
            q.print();
            q.exec();
            System.out.println("Kết quả: " + q.getScore());
        }
        
        for (int i = 0; i < questions.size(); i++) {
            Question q = questions.get(i);
            
            if (q instanceof Object) {
                System.out.println(i + ". Object");
            }
            
            if (q instanceof Question) {
                System.out.println(i + ". Question");
            }
            
            if (q instanceof MultipleChoice) {
                System.out.println("Câu hỏi " + i + " là câu hỏi MultipleChoice");
            } else if (q instanceof FillWord) {
                System.out.println("Câu hỏi " + i + " là câu hỏi FillWord");
            } else {
                System.out.println("Câu hỏi " + i + " là kiểu câu hỏi chưa xác định");
            }
        }
        
    }
    
}
