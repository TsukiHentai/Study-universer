/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ex2arraylist;

import java.util.*;

/**
 *
 * @author asus
 */
public class Ex2ArrayList {

    public static void printArray(ArrayList array) {
        System.out.println("----------------------------------");
        for (int i = 0; i < array.size(); i++) {
            System.out.println("array[" + i + "] = " + array.get(i));
        }
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ArrayList<Integer> array = new ArrayList<Integer>();
        
        // Thêm một phần tử vào cuối mảng.
        array.add(123);
        array.add(456);
        
        // In ra mảng
        for (int i = 0; i < array.size(); i++) {
            System.out.println("array[" + i + "] = " + array.get(i));
        }
        
        // Sửa giá trị 1 phần tử.
        array.set(1, 999);
        
        // In ra mảng
        for (Integer element: array) {
            System.out.println("array: " + element);
        }
        
        // Thêm một phần tử vào giữa mảng.
        // Thêm phần tử có giá trị 111 vào vị trí index = 1 (vị trí thứ 2)
        array.add(1, 111);
        
        printArray(array);
        
        // Chèn thêm vào cuối mảng
        array.add(3, 333);
        
        printArray(array);
        
        // Xóa bỏ 1 phần tử khỏi mảng
        // Xóa bỏ phần tử có index = 2 (vị trí thứ 3)
        System.out.println("Xóa bỏ phần tử ở vị trí số 2");
        array.remove(2);
        
        printArray(array);
        
        // Sắp xếp mảng
        IntegerComparator compare = new IntegerComparator();
        array.sort(compare);
        
        printArray(array);
        
        // Sao chép mảng (clone)
        ArrayList<Integer> arrayClone = (ArrayList<Integer>)array.clone();
        
        // anonymous class
        arrayClone.sort(new Comparator() {
            @Override
            public int compare(Object o1, Object o2) {
                if ((o1 instanceof Integer) && (o2 instanceof Integer)) {
                    Integer i1 = (Integer) o1;
                    Integer i2 = (Integer) o2;
                    
                    if (i1 > i2) {
                        return -1;
                    } else if (i1 < i2) {
                        return 1;
                    } else {
                        return 0;
                    }
                } else {
                    return 0;
                }
            }
        });
        
        System.out.println("arrayClone");
        printArray(arrayClone);
        
        System.out.println("array");
        printArray(array);
        
        // Xóa các phần tử thỏa mãn điều kiện
        array.removeIf(new Filter());
        
        // Mảng sau khi loại bỏ các phần tử lớn hơn 200
        printArray(array);
        
        // Xóa toàn bộ mảng
        arrayClone.clear();
        System.out.println("Mảng sau khi xóa hết các phần tử");
        printArray(arrayClone);
    }
    
}
