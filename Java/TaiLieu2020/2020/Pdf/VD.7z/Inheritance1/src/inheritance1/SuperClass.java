/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;

/**
 *
 * @author asus
 */
public abstract class SuperClass {
    protected int nName;
    SuperClass() {
        nName = 0;
        System.out.println("This is SuperClass!!!");
    }
    
    SuperClass(int nName) {
        this.nName = nName;
        System.out.println("This is SuperClass with params!!!");
    }
    
    public void shout() {
        System.out.println("---Super---");
    }
    
    public abstract void printName();
}
