/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;


import example.IExample;
/**
 *
 * @author asus
 */
public class Inheritance1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SuperClass superClass; // = new SuperClass();
        TinyClass tiny = new TinyClass();
        // System.out.println("superClass.shout()");
        // superClass.shout();
        System.out.println("tiny.shout()");
        tiny.shout();
        System.out.println("tiny.printName()");
        tiny.printName();
        System.out.println("Message:");
        tiny.print("Example message!");
        
        //superClass = (SuperClass) subClass;
        //System.out.println("superClass.shout()");
        //superClass.shout();
        //System.out.println("superClass.printName()");
        //superClass.printName();
        
        IExample iExam;
        iExam = (IExample) tiny;
        
        System.out.println("IExample.print");
        iExam.print("Message from IExample!!!!!!!!");
        iExam.exam1();
        iExam.exam2();
    }
    
}
