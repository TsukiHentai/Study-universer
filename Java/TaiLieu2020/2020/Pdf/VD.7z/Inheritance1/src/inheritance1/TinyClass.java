/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;

/**
 *
 * @author asus
 */
public class TinyClass extends SubClass {
    public TinyClass() {
        
    }
    
    @Override
    public void print(String message) {
        System.out.println("nName: " + nName + " | " + message);
    }
    
    @Override
    public void exam1() {
        System.out.println("Implement of exam1!");
    }
    
    @Override
    public void exam2() {
        System.out.println("Implement of exam2222222");
    }
}
