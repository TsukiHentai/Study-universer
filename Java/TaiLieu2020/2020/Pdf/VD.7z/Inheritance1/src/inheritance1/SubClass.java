/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package inheritance1;

import example.IExample;

/**
 *
 * @author asus
 */
public abstract class SubClass extends SuperClass implements IExample {
    public SubClass() {
        super(2);
        System.out.println("Default contructor in SubClass.");
    }
    
    @Override
    public void shout() {
        System.out.println("---Sub Class---");
        super.shout();
    }
    
    @Override
    public void printName() {
        System.out.println("SubClass");
    }
}
