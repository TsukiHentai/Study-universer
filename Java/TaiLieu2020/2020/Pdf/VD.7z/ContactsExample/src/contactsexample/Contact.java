/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contactsexample;

import java.util.*;

/**
 *
 * @author asus
 */
public class Contact {
    private String name;
    private String phoneNumber;
    
    public Contact() {
        this("Unknown", "");
    }
    
    public Contact(String name) {
        this(name, "");
    }
    
    public Contact(String name, String phoneNumber) {
        this.name = name;
        this.phoneNumber = phoneNumber;
    }
    
    public String getName() {
        return name;
    }
    
    public void setName(String name) {
        this.name = name;
    }
    
    public String getPhoneNumber() {
        return phoneNumber;
    }
    
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
    
    public String toString() {
        return name + ": " + phoneNumber;
    }
    
    @Override
    public boolean equals(Object o1) {
        if ((o1 instanceof Contact)) {
            return this.name.equals(((Contact) o1).getName());
        } else {
            return false;
        }
    }
}
