/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contactsexample;

import java.util.*;

/**
 *
 * @author asus
 */
public class ContactBook {
    private ArrayList<Contact> contacts;
    
    public ContactBook() {
        contacts = new ArrayList<>();
    }
    
    public void addContact(Contact contact) {
        contacts.add(contact);
    }
    
    public void removeContact(Contact contact) {
        contacts.remove(getIndexOf(contact));
    }
    
    public int getIndexOf(Contact contact) {
        // Trả về vị trí của phần tử đầu tiên có giá trị contact
        // Để sử dụng indexOf sẽ cần Override phương thức equals ở lớp Contact
        return contacts.indexOf(contact);
    }
    
    // Tìm kiếm theo tên
    public Contact find(String name) {
        return contacts.get(getIndexOf(new Contact(name)));
    }
    
    // Sắp xếp danh sách liên hệ theo tên
    public void sortByName() {
        // Lambda (hỗ trợ từ java 8)
        contacts.sort((Object o1, Object o2) -> {
            if ((o1 instanceof Contact) && (o2 instanceof Contact)) {
                Contact c1 = (Contact) o1;
                Contact c2 = (Contact) o2;
                
                return c1.getName().compareTo(c2.getName());
            } else {
                return 0;
            }
        });
    }
    
    public void print() {
        System.out.println("--- Danh sách liên hệ ---");
        for (int i = 0; i < contacts.size(); i++) {
            System.out.println(contacts.get(i).toString());
        }
        System.out.println("---------- Hết ----------");
    }
}
