/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package contactsexample;


import java.util.Scanner;

/**
 *
 * @author asus
 */
public class ContactsExample {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        ContactBook contactBook = new ContactBook();
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Bạn có muốn nhập thêm liên hệ (Y/N):");
        String sel = sc.nextLine().trim();
        while (sel.equals("Y") || sel.equals("y")) {
            System.out.print("Nhập tên: ");
            String name = sc.nextLine();
            System.out.print("Nhập số điện thoại: ");
            String phoneNumber = sc.nextLine();
            
            Contact contact = new Contact(name, phoneNumber);
            contactBook.addContact(contact);
            
            System.out.println("Bạn có muốn nhập thêm liên hệ (Y/N):");
            sel = sc.nextLine().trim();
        }
        
        // In ra danh sách liên hệ
        contactBook.print();
        
        // Sắp xếp danh sách liên hệ theo tên
        contactBook.sortByName();
        System.out.println("Danh sách liên hệ sau khi sắp xếp:");
        contactBook.print();
        
        // Tìm kiếm người trong danh sách liên hệ.
        String findName = sc.nextLine();
        System.out.println(contactBook.find(findName));
        
    }
    
}
