/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exceptionsample;

import java.util.Scanner;


/**
 *
 * @author asus
 */
public class ExceptionSample {

    public static double div(int a, int b) throws ExceptionDivByZero, ExceptionDivZeroZero {
        if (b == 0) {
            if (a == 0) {
                ExceptionDivZeroZero divZeroZero = new ExceptionDivZeroZero();
                throw divZeroZero;
            } else {
                throw new ExceptionDivByZero();
            }
        }
        
        return a / b;
    }
    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        Scanner sc = new Scanner(System.in);
        
        int a, b;
        double ab;
        
        System.out.println("Nhập vào 2 số");
        System.out.print("a = ");
        a = sc.nextInt();
        System.out.print("b = ");
        b = sc.nextInt();
        for (int i = a; i <= b; i++) {
            int x, y;
            x = i;
            y = b - (i - a);
            try {
                ab = div(x, y);
            } catch (ExceptionDivByZero ex) {
                System.out.println("Có lỗi xảy ra! - DivByZero");
                System.out.println(ex.getMessage());
                continue;
            } catch (ExceptionDivZeroZero ex) {
                System.out.println("Có lỗi xảy ra! ------ 0/0");
                System.out.println(ex.getMessage());
                break;
            } finally {
                System.out.println("------- finally code -------");
                System.out.println("Thử thực hiện phép chia: " + x + " / " + y);
                System.out.println("------- finally code -------");
            }

            System.out.println(x + " / " + y + " = " + ab);
        }
        // System.out.println("Chương trình đã hoàn thành mà không có lỗi xảy ra!");
    }
    
}

class ExceptionDivByZero extends Exception {
    @Override
    public String getMessage() {
        return "Phép chia cho số 0";
    }
}

class ExceptionDivZeroZero extends Exception {
    @Override
    public String getMessage() {
        return "Phép chia giữa 2 số 0: 0/0";
    }
}